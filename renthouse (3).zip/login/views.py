from django.shortcuts import render, redirect
from login.models import User
from django.http import HttpResponse
from django.conf import settings
from login.models import Img
import json  # 用于数据交互

'''登录系统界面'''


def loginSystem(request):
    if request.method == "POST":  # 当传递参数后 submit
        user_name = request.POST.get("username", None)  # 获得输入的用户名
        pass_word = request.POST.get("password", None)  # 获得输入的密码
        user = User.objects.filter(username=user_name).filter(password=pass_word)
        print(user.values('rentorsell'))
        if user.count() == 1:  # 检查用户名和密码是否为空 (注册界面通过前端js来判断)
            if user.values("rentorsell")[0]['rentorsell'] == 1:
                # rentorsell ==1 为sell
                request.session["rentorsell"] = 1
                return redirect('/sell')
            else:
                # rentorsell ==0 为rent
                request.session["rentorsell"] = 0
                return redirect('/rent')
        else:
            return HttpResponse("登录失败请检查用户名或密码")
    return render(request, 'login.html')


'''注册界面'''


def registerSystem(request):
    # 先查数据库当中是否有数据、然后没有数据后再添加
    if request.method == "POST":
        ''' 获得相关数据 '''
        user_name = request.POST.get("username", None)
        pass_word = request.POST.get("password", None)
        gender = request.POST.get("gender", None)
        rentorsell = request.POST.get("rentorsell", None)
        identify_number = request.POST.get("Id", None)
        address = request.POST.get("address", None)
        email = request.POST.get("Email", None)
        phone = request.POST.get("Phone", None)
        # 根据输入的user_name 来查询数据库有没有当前用户
        result = User.objects.filter(username=user_name).count()
        if result > 0:
            return HttpResponse("注册失败提醒 当前存在该用户")
        else:
            # 写入注册信息
            try:
                User.objects.create(username=user_name,
                                    password=pass_word,
                                    rentorsell=rentorsell,
                                    gender=gender,
                                    identifyid=identify_number,
                                    address=address,
                                    email=email,
                                    phone=phone)
            except Exception as e:
                return HttpResponse('注册失败')
            return redirect('/login')

    return render(request, 'register.html')


'''主页面'''


def mainPageSystem(request):
    return render(request, 'main.html')


'''跳转界面函数'''


def sell(request):
    return render(request, 'sell.html')


def rent(request):
    return render(request, 'rent.html')


def analyze(request):
    return render(request, 'sell.html')


def registers(request):
    return render(request, 'register.html')

# def pic_upload(request):##上传时界面
#     return render(request,'sell.html')
# def pic_handle(request):   ##提交
#     f1=request.FILES.get('pic')
#     fname='%s/img/%s'%(settings.MEDIA_ROOT,f1.name)
#     with open(fname,'wb')as pic:
#             pic.write(c)
#     p1=PicTest()
#     p1.pic='book_app/%s'%f1.name
#     p1.save()
#     return  HttpResponse('上传成功！')
# def pic_show(request):   ##展示
#     pic=PicTest.objects.all()
#     # pic=PicTest.objects.get(id=1)
#     context={'Tem_pic':pic}
#     return render(request,'rent.html',context)
# def pic_upload(request):
#     if request.method=='GET':
#         return render(request,'rent.html')
#     else:
#         file_obj=request.POST.get('file')
#         print(file_obj)
#         PicTest.objects.create(pic=file_obj)
#         return render(request,'rent.html')



def uploadImg(request):#照片的传递
    if request.method=='POST':
        print(request.POST)
        img=Img(img_url=request.FILES.get('img'))
        img.save()
    return render(request,'sell.html')
def showImg(request):
    imgs=Img.objects.all()
    context={
        'imgs':imgs

    }
    return render(request,'rent.html',context)


##下面是房屋信息的传递
def sell_gain(request):
    if request.method=="POST":
        '''获得相关数据'''






