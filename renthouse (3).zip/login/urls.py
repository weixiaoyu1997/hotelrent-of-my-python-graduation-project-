from django.conf.urls import include,url
from . import views

urlpatterns = [
    url('login',views.loginSystem, name = 'loginSystem'), #登录界面
    url('register',views.registerSystem,name = 'registerSystem'), #注册用户信息
    url('mainPageSystem',views.mainPageSystem,name='mainPageSystem'), #主界面
]